
    split_img = Image.Image.split(NOW_img)